nums = input().split()
print(*nums[::2])