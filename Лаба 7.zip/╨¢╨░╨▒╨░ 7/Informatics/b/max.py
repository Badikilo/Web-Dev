a = int(input())
b = int(input())
if(a>b):
    print("a greater than b")
else:
    print("b greater than a")