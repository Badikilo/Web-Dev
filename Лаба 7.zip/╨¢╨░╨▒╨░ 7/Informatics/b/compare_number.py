n1,n2 = int(input()), int(input())
print(1 if n1 > n2 else 2 if n1 < n2 else 0)