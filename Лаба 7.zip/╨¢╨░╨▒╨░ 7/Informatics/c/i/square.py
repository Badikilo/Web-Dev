a, b = int(input()), int(input())
for i in range(a, b+1):
    if i**2 <=b:
        print(i**2, end=" ")