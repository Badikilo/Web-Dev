n1, n2 = int(input()), int(input())
for i in range(n1, n2+1):
    if i % 2 == 0:
        print(i, end=" ")