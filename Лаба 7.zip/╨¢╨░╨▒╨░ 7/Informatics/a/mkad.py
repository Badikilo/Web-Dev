v = int(input())
t = int(input())

if(v>0):
    print(abs(109-v*t))
else:
    print(v*t + 109)