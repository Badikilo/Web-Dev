N = int(input("Введите кол-во школьников "))

K = int(input("Введите кол-во яблок "))

S = K//N
print(S)