def swap_case(s):
    return s.swapcase()
s = input()
print(swap_case(s))