def print_full_name(first,last):
    return first + " " + last
first_name = input()
last_name = input()
print(f"Hello " + print_full_name(first_name, last_name) + " Добро Пожаловать")