a,b,m = int(input()), int(input()), int(input())
print(a**b)
print((a**b) % m)