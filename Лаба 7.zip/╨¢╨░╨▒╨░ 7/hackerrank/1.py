a, b = int(input()), int(input())
print(a+b)
print(a-b)
print(a*b)
