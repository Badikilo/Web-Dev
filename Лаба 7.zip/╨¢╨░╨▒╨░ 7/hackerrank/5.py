s = input("Введи свое имя брат ")
print(f"Assalaumagaleikym {s}")
t = input()
if(t == "Uagaleikymassalam"):
    print("Masha Allah brat")
else:
    print("Brat, nu davai po-novoy!")